import React, { useState } from "react";
import { View, Text, Pressable, LayoutAnimation, Platform, UIManager } from "react-native";

// Enable LayoutAnimation support for Android devices
if (Platform.OS === "android" && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function AnimatedDemo() {
  const [expanded, setExpanded] = useState(false);

  const toggleExpand = () => {
    // 1. Tell React Native to automatically animate whatever UI change happens on the NEXT render
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    
    // 2. Update normal React state (this changes component height and layout structure)
    setExpanded(!expanded);
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Pressable onPress={toggleExpand}>
        {/* Normal View: LayoutAnimation handles the smooth size change automatically */}
        <View
          style={{
            width: 250,
            padding: 16,
            backgroundColor: "#2ECC71",
            borderRadius: 8,
          }}
        >
          <Text style={{ color: "white", fontWeight: "bold" }}>
            {expanded ? "Tap to Collapse" : "Tap to Expand"}
          </Text>

          {/* Conditional rendering: LayoutAnimation smoothly slides open/closed when state changes */}
          {expanded && (
            <Text style={{ color: "white", marginTop: 10 }}>
              Notice how we didn't use any Animated.Value! React Native automatically calculated 
              the layout difference and animated the height transition for us.
            </Text>
          )}
        </View>
      </Pressable>
    </View>
  );
}