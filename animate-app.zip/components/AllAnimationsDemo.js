import React, { useRef, useState } from "react";
import {
  View,
  Text,
  Pressable,
  Animated,
  PanResponder,
  LayoutAnimation,
  Platform,
  UIManager,
} from "react-native";

// Enable LayoutAnimation for legacy Android engine safely without warnings
if (
  Platform.OS === "android" &&
  UIManager.setLayoutAnimationEnabledExperimental &&
  !global?.nativeFabricUIManager // Only call if NOT using New Architecture
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function AllAnimationsDemo() {
  const [expanded, setExpanded] = useState(false);

  // TOPIC 1: Animated API Values
  const opacity = useRef(new Animated.Value(1)).current;
  const scale = useRef(new Animated.Value(1)).current;

  const pulseCard = () => {
    Animated.sequence([
      Animated.parallel([
        // Use useNativeDriver: false here to match the PanResponder driver
        Animated.timing(opacity, { toValue: 0.5, duration: 200, useNativeDriver: false }),
        Animated.spring(scale, { toValue: 1.08, useNativeDriver: false }),
      ]),
      Animated.parallel([
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: false }),
        Animated.spring(scale, { toValue: 1, useNativeDriver: false }),
      ]),
    ]).start();
  };

  // TOPIC 2: LayoutAnimation
  const toggleDetails = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpanded(!expanded);
  };

  // TOPIC 3: Gesture Control (PanResponder)
  const pan = useRef(new Animated.ValueXY()).current;

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], {
        useNativeDriver: false,
      }),
      onPanResponderRelease: () => {
        Animated.spring(pan, { toValue: { x: 0, y: 0 }, useNativeDriver: false }).start();
      },
    })
  ).current;

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Animated.View
        {...panResponder.panHandlers}
        style={{
          width: 280,
          padding: 20,
          backgroundColor: "#4A90E2",
          borderRadius: 12,
          opacity: opacity,
          transform: [{ scale }, ...pan.getTranslateTransform()],
        }}
      >
        <Text style={{ color: "white", fontSize: 20, fontWeight: "bold" }}>
          John Doe
        </Text>
        <Text style={{ color: "white", marginBottom: 10 }}>Software Engineer</Text>

        {expanded && (
          <View style={{ marginTop: 10, borderTopWidth: 1, borderColor: "#ffffff55", paddingTop: 10 }}>
            <Text style={{ color: "white" }}>Department: Mobile Dev</Text>
            <Text style={{ color: "white" }}>Location: Pune, India</Text>
          </View>
        )}
      </Animated.View>

      <View style={{ flexDirection: "row", marginTop: 30, gap: 10 }}>
        <Pressable onPress={pulseCard} style={{ backgroundColor: "#333", padding: 10, borderRadius: 6 }}>
          <Text style={{ color: "white" }}>1. Pulse (Animated API)</Text>
        </Pressable>

        <Pressable onPress={toggleDetails} style={{ backgroundColor: "#2ECC71", padding: 10, borderRadius: 6 }}>
          <Text style={{ color: "white" }}>
            2. {expanded ? "Hide" : "Show"} Details (Layout)
          </Text>
        </Pressable>
      </View>

      <Text style={{ marginTop: 15, color: "#666" }}>
        3. Drag the card directly to test Gestures!
      </Text>
    </View>
  );
}