import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Picker } from '@react-native-picker/picker';

export default function PickerDemo() {
  const [selectedValue, setSelectedValue] = useState('javascript');

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Select a Language:</Text>
      
      <Picker
        selectedValue={selectedValue}
        onValueChange={(itemValue) => setSelectedValue(itemValue)}
        style={styles.picker}
      >
        <Picker.Item label="JavaScript" value="javascript" />
        <Picker.Item label="TypeScript" value="typescript" />
        <Picker.Item label="Python" value="python" />
        <Picker.Item label="Java" value="java" />
      </Picker>

      <Text style={styles.result}>Selected: {selectedValue}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  picker: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
  },
  result: {
    marginTop: 20,
    fontSize: 16,
    color: '#333',
  },
});