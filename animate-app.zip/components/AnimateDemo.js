import React, { useRef } from "react";
import { View, Text, Pressable, Animated } from "react-native";

export default function AnimateDemo() {
  // 1. Create animation values that persist across renders without causing re-renders
  const opacity = useRef(new Animated.Value(0)).current; // Starts invisible (0)
  const translateY = useRef(new Animated.Value(50)).current; // Starts 50px below final position

  const showCard = () => {
    // 2. Run both opacity and translation animations at the exact same time
    Animated.parallel([
      Animated.timing(opacity, {
        toValue: 1, // Fade in to fully visible
        duration: 400,
        useNativeDriver: true, // Offloads animation work to the native UI thread
      }),
      Animated.timing(translateY, {
        toValue: 0, // Move up to original position
        duration: 400,
        useNativeDriver: true,
      }),
    ]).start();
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Pressable onPress={showCard}>
        <Text style={{ marginBottom: 20, color: "blue" }}>Tap to Reveal Card</Text>
      </Pressable>

      {/* 3. Attach animated values directly to an Animated.View */}
      <Animated.View
        style={{
          width: 200,
          padding: 20,
          backgroundColor: "#4A90E2",
          borderRadius: 8,
          opacity: opacity, // Binds opacity value (0 -> 1)
          transform: [{ translateY }], // Binds vertical movement (50 -> 0)
        }}
      >
        <Text style={{ color: "white" }}>Hello! I smoothly faded and slid up.</Text>
      </Animated.View>
    </View>
  );
}