import React, { useRef } from "react";
import { View, Text, Animated, PanResponder } from "react-native";

export default function GestureDemo() {
  // 1. Create a 2D position tracker holding both X and Y coordinates (starts at {x: 0, y: 0})
  const pan = useRef(new Animated.ValueXY()).current;

  // 2. Set up the gesture listener (tracks finger touch, move, and release)
  const panResponder = useRef(
    PanResponder.create({
      // Ask React Native to give this component control over touch events
      onStartShouldSetPanResponder: () => true,

      // As the user drags their finger, update the pan position values in real-time
      onPanResponderMove: Animated.event(
        [null, { dx: pan.x, dy: pan.y }], // Maps finger displacement (dx, dy) directly to (pan.x, pan.y)
        { useNativeDriver: false } // Gestures require JS thread listener access for coordinates
      ),

      // When the user lifts their finger, smoothly spring the card back to center
      onPanResponderRelease: () => {
        Animated.spring(pan, {
          toValue: { x: 0, y: 0 }, // Reset position back to origin
          useNativeDriver: false,
        }).start();
      },
    })
  ).current;

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      {/* 3. Attach both the drag gesture handlers and the animated position style */}
      <Animated.View
        {...panResponder.panHandlers} // Listens for touch, drag, and release events
        style={{
          width: 150,
          height: 150,
          backgroundColor: "#E74C3C",
          borderRadius: 16,
          justifyContent: "center",
          alignItems: "center",
          transform: pan.getTranslateTransform(), // Converts {x, y} into [{translateX}, {translateY}]
        }}
      >
        <Text style={{ color: "white", fontWeight: "bold" }}>Drag Me Around!</Text>
      </Animated.View>
    </View>
  );
}