import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import AnimatedDemo from './components/AnimatedDemo';
import GestureDemo from './components/GestureControl';
import AllAnimationsDemo from './components/AllAnimationsDemo';
import PickerDemo from './components/PickerDemo';
 
export default function App() {
  return (
    <View style={styles.container}>
    <AllAnimationsDemo/>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
