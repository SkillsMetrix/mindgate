import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  Button,
  Alert,
  StyleSheet,
  ActivityIndicator,
} from "react-native";

import * as Calendar from "expo-calendar/legacy";
import * as Notifications from "expo-notifications";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export default function App() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCalendarEvents();
  }, []);

  const loadCalendarEvents = async () => {
    try {
      const { status } =
        await Calendar.requestCalendarPermissionsAsync();

      if (status !== "granted") {
        Alert.alert("Calendar permission denied");
        return;
      }

      const calendars = await Calendar.getCalendarsAsync(
        Calendar.EntityTypes.EVENT
      );

      const calendarIds = calendars.map(
        (calendar) => calendar.id
      );

      const startDate = new Date();

      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 30);

      const calendarEvents = await Calendar.getEventsAsync(
        calendarIds,
        startDate,
        endDate
      );

      setEvents(calendarEvents);
    } catch (error) {
      console.log(error);
      Alert.alert("Error", error.message);
    } finally {
      setLoading(false);
    }
  };

  const sendTestNotification = async () => {
    const { status } =
      await Notifications.requestPermissionsAsync();

    if (status !== "granted") {
      Alert.alert("Notification permission denied");
      return;
    }

    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Test Notification",
        body: "This notification appeared after 10 seconds",
      },
      trigger: {
        type:
          Notifications.SchedulableTriggerInputTypes
            .TIME_INTERVAL,
        seconds: 10,
      },
    });

    Alert.alert(
      "Success",
      "Notification scheduled for 10 seconds"
    );
  };

  const scheduleMeetingReminders = async () => {
    const { status } =
      await Notifications.requestPermissionsAsync();

    if (status !== "granted") {
      Alert.alert("Notification permission denied");
      return;
    }

    let scheduledCount = 0;

    for (const event of events) {
      const meetingTime = new Date(event.startDate);

      const reminderTime = new Date(
        meetingTime.getTime() - 15 * 60 * 1000
      );

      const secondsUntilReminder = Math.floor(
        (reminderTime.getTime() - Date.now()) / 1000
      );

      if (secondsUntilReminder > 0) {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: "Upcoming Meeting",
            body: `${event.title} starts in 15 minutes`,
          },
          trigger: {
            type:
              Notifications
                .SchedulableTriggerInputTypes
                .TIME_INTERVAL,
            seconds: secondsUntilReminder,
          },
        });

        scheduledCount++;
      }
    }

    Alert.alert(
      "Done",
      `${scheduledCount} reminder(s) scheduled`
    );
  };

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>
         Upcoming Calendar Meetings
      </Text>

      <View style={styles.buttonContainer}>
        <Button
          title="Test Notification"
          onPress={sendTestNotification}
        />
      </View>

      <View style={styles.buttonContainer}>
        <Button
          title="Schedule Meeting Reminders"
          onPress={scheduleMeetingReminders}
        />
      </View>

      <FlatList
        data={events}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.title}>
              {item.title}
            </Text>

            <Text style={styles.date}>
              {new Date(
                item.startDate
              ).toLocaleString()}
            </Text>
          </View>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            No meetings found in the next 30 days
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    paddingTop: 50,
    backgroundColor: "#fff",
  },

  heading: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 15,
    textAlign: "center",
  },

  buttonContainer: {
    marginBottom: 10,
  },

  card: {
    backgroundColor: "#f5f5f5",
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },

  title: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
  },

  date: {
    fontSize: 14,
  },

  emptyText: {
    textAlign: "center",
    marginTop: 30,
    fontSize: 16,
  },

  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});