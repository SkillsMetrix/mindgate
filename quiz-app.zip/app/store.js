
import { configureStore } from '@reduxjs/toolkit'
import quizReducer from '../features/quizSlice'
import questionReducer from '../features/questionSlice'
 export const store= configureStore({
    reducer:{
        quiz: quizReducer,
        questions:questionReducer
    }
})