import api from "../api/api"
import { getCached, setCached } from "../utils/apiCache"

const USERS_CACHE_KEY = "users-list"

export const registerUser=async(userData) =>{
    const response= await api.post("/users",userData)
    return response.data
}



export const loginUser=async(username,password) =>{
    const response= await api.post("/auth/login",{
        username,password
    })
    return response.data
}


export const loadUserss=async() =>{
    try {
        const response = await api.get("/users")
        await setCached(USERS_CACHE_KEY, response.data)
        return response.data
    } catch (error) {
        // Network/timeout/server failure - fall back to the last known good
        // list so the screen still has something to show.
        const cached = await getCached(USERS_CACHE_KEY)
        if (cached) {
            console.log('[API] Server not available - showing cached users data', { isFresh: cached.isFresh })
            return cached.data
        }
        throw error
    }
}


export const updateUserss=async(id,userData) =>{
    const response= await api.put(`/users/${id}`,userData)
    return response.data
}


export const deleteUserss=async(id) =>{
    const response= await api.delete(`/users/${id}`)
    return response.data
}
