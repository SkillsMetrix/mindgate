import AsyncStorage from '@react-native-async-storage/async-storage'

const CACHE_PREFIX = 'cache:'
const DEFAULT_TTL_MS = 5 * 60 * 1000 // 5 minutes

// Best-effort local cache for API responses, backed by AsyncStorage. Used to
// keep screens showing the last known good data when a request fails
// (offline, timeout, server error) instead of going blank.

export const getCached = async (key) => {
  try {
    const raw = await AsyncStorage.getItem(CACHE_PREFIX + key)
    if (!raw) return null

    const { data, savedAt, ttl } = JSON.parse(raw)
    return { data, isFresh: Date.now() - savedAt < ttl }
  } catch {
    // Corrupt/unavailable storage shouldn't break the caller - just miss.
    return null
  }
}

export const setCached = async (key, data, ttl = DEFAULT_TTL_MS) => {
  try {
    await AsyncStorage.setItem(
      CACHE_PREFIX + key,
      JSON.stringify({ data, savedAt: Date.now(), ttl })
    )
  } catch {
    // Caching is an optimization, not a requirement - ignore write failures.
  }
}

export const clearCached = async (key) => {
  try {
    await AsyncStorage.removeItem(CACHE_PREFIX + key)
  } catch {
    // Nothing to do if removal fails - a stale/missing entry is harmless.
  }
}
