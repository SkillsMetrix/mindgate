import axios from 'axios'
import Constants from 'expo-constants'
import { Platform } from 'react-native'
import AsyncStorage from '@react-native-async-storage/async-storage'

const BACKEND_PORT = 3000
const REQUEST_TIMEOUT_MS = 15000
const MAX_RETRIES = 2
const RETRY_BASE_DELAY_MS = 500

// On web, the backend runs on the same machine, so localhost works.
// On a device/emulator (Expo Go or a dev build), "localhost" refers to the
// device itself, not your computer - so we derive the dev machine's LAN IP
// from the Metro/Expo debugger host instead.
const getBaseUrl = () => {
  if (Platform.OS === 'web') {
    return `http://localhost:${BACKEND_PORT}`
  }

  const hostUri =
    Constants.expoConfig?.hostUri ?? Constants.expoGoConfig?.debuggerHost

  const host = hostUri?.split(':')[0]

  if (!host) {
    console.warn(
      'Could not detect dev machine IP from Expo host info; falling back to localhost. ' +
        'If requests fail on a device/emulator, set your machine\'s LAN IP manually in api/api.js.'
    )
    return `http://localhost:${BACKEND_PORT}`
  }

  // Android emulator (not a physical device) maps the host machine to 10.0.2.2
  if (Platform.OS === 'android' && host === 'localhost') {
    return `http://10.0.2.2:${BACKEND_PORT}`
  }

  return `http://${host}:${BACKEND_PORT}`
}

const api = axios.create({
  baseURL: getBaseUrl(),
  timeout: REQUEST_TIMEOUT_MS,
})

// Attach the stored JWT to every request, so screens/services never have to.
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// Network drops and timeouts have no response at all; 5xx means the server
// itself failed. Both are worth retrying. 4xx means the request was bad, so
// retrying it would just fail the same way again.
const isRetryableError = (error) =>
  error.code === 'ECONNABORTED' || !error.response || error.response.status >= 500

// Normalizes any axios failure into one shape with a user-presentable
// message, so screens can show `error.message` directly instead of
// re-deriving it from status codes.
export class ApiError extends Error {
  constructor(message, { status = null, isTimeout = false, isNetworkError = false, cause } = {}) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.isTimeout = isTimeout
    this.isNetworkError = isNetworkError
    this.cause = cause
  }
}

const toApiError = (error) => {
  if (error.code === 'ECONNABORTED') {
    return new ApiError(
      'The request timed out. Please check your connection and try again.',
      { isTimeout: true, cause: error }
    )
  }

  if (!error.response) {
    return new ApiError(
      'Unable to reach the server. Please check your connection.',
      { isNetworkError: true, cause: error }
    )
  }

  const { status, data } = error.response
  const serverMessage = data?.message

  if (status === 401) {
    return new ApiError(serverMessage || 'Your session has expired. Please log in again.', { status, cause: error })
  }
  if (status === 404) {
    return new ApiError(serverMessage || 'The requested resource was not found.', { status, cause: error })
  }
  if (status >= 500) {
    return new ApiError(serverMessage || 'The server ran into a problem. Please try again shortly.', { status, cause: error })
  }

  return new ApiError(serverMessage || 'Something went wrong. Please try again.', { status, cause: error })
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const config = error.config ?? {}
    const method = (config.method || 'get').toLowerCase()

    // Only auto-retry idempotent GET requests - retrying a POST/PUT/DELETE
    // on a flaky connection risks duplicating a write (e.g. double-submitting
    // a login or an edit).
    if (method === 'get' && isRetryableError(error)) {
      config.__retryCount = config.__retryCount || 0

      if (config.__retryCount < MAX_RETRIES) {
        config.__retryCount += 1
        const delay = RETRY_BASE_DELAY_MS * 2 ** (config.__retryCount - 1)
        const reason = error.code === 'ECONNABORTED'
          ? 'timeout'
          : !error.response
            ? 'server unreachable'
            : `server error ${error.response.status}`

        console.log(
          `[API] ${reason} on ${config.url} - retrying (${config.__retryCount}/${MAX_RETRIES}) in ${delay}ms`
        )

        await sleep(delay)
        return api(config)
      }
    }

    return Promise.reject(toApiError(error))
  }
)

export default api
