import React, { useState } from 'react';
import { View, Text, Button, Switch, StyleSheet } from 'react-native';
import { calculateNextValue } from './counterMath';
 
export default function CounterFeature() {
  const [count, setCount] = useState(0);
  const [multiplyMode, setMultiplyMode] = useState(false);

  const handleIncrement = () => {
    // Component integrates the external pure business logic helper
    const nextVal = calculateNextValue(count, 2, multiplyMode); // Uses a step of 2 for demo variety
    setCount(nextVal === 0 && multiplyMode ? 1 : nextVal); 
  };

  return (
    <View style={styles.container} testID="counter-feature-container">
      <Text style={styles.title}>JS Unified Testing Suite</Text>
      
      <Text style={styles.valueText} testID="counter-value">
        Current Count: {count}
      </Text>

      <View style={styles.row}>
        <Text>Multiply Mode (x2 instead of +2):</Text>
        <Switch
          testID="mode-switch"
          value={multiplyMode}
          onValueChange={(value) => {
            setMultiplyMode(value);
            if(value && count === 0) setCount(1); 
          }}
        />
      </View>

      <Button title="Increment Count" onPress={handleIncrement} testID="increment-button" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
  valueText: { fontSize: 24, marginVertical: 15 },
  row: { flexDirection: 'row', alignItems: 'center', marginVertical: 10, gap: 10 }
});