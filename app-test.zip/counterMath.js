/**
 * Pure JavaScript utility function.
 * Zero dependency on React or UI components—perfect for pure Unit Testing.
 */
export const calculateNextValue = (current, step, multiplyMode) => {
  if (multiplyMode) {
    return current * step;
  }
  return current + step;
};